SDL version 2.0.18
SDL2_image-devel-2.0.5-VC
SDL2_mixer-devel-2.0.4-VC
SDL2_net-2.0.1
